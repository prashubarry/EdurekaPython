class Edureka:
    empcount=0

print("Edureka.__dict__:",Edureka.__dict__)

print("Edureka.__doc__:",Edureka.__doc__)

print("Edureka.__name__",Edureka.__name__)

print("Edureka.__module__:",Edureka.__module__)

print("Edureka.__bases__:",Edureka.__bases__)