import random

print(random.getstate)

print(random.uniform(6,2))


import random

num = random.randrange(100)
print(num)

ran=random.randrange(0,100,20)
print(ran)

inte=random.randint(0,30)
print(inte)