a=50

class Edureka(self):
    b=60
    print(b)

ob=Edureka