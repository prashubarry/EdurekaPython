import os.path
print(os.path.join('/Users/adhyapakss/PycharmProjects','/Users/adhyapakss'))

print(os.path.abspath('/Users/adhyapakss/PycharmProjects/DS_mod3'))

print(os.path.normpath('/Users/adhyapakss/PycharmProjects'))

print(os.path.split('/Users/adhyapakss/PycharmProjects/DS_mod3/os_path.py'))

print(os.path.exists('/User/edureka'))

print(os.path.isdir('User/adhyapakss/PycharmProjects/DS_mod3'))

print(os.walk('/Users/adhyapakss/PycharmProjects'))