class Foo(object):
    def math(self):
        pass

import math
print(dir(math))

