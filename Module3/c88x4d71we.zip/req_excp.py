def print_name(str):
    print("Welcome to Python, ",str)
    return()

print_name()

