import datetime

print(datetime.MAXYEAR)

print(datetime.MINYEAR)

print(datetime.time)

print(datetime.timezone)




import datetime
print(datetime.datetime.today())

now=datetime.datetime.today()
other=datetime.datetime(1995,3,12,22,10)
print(now-other)
datetime.timedelta(18901,55547,421000)
print(now-other)