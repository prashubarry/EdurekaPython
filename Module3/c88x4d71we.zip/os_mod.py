import os

print(os.name)

print(os.environ)

print(os.getlogin())

print(os.getppid)


import os

print(os.getcwd())

print(os.chdir('d:/Python'))

print(os.mkdir('d:/Python/Py'))

print(os.rmdir('d:/Python/Py'))

