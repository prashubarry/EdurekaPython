class Foo(object):
    def meth(self):
       pass
