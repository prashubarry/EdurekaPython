import math

print(math.ceil(10.098))

print(math.copysign(10,-1))

print(math.fabs(-19.7))

print(math.exp(5))

print(math.expm1(2))

print(math.log(10,10))


print(math.acos(0.5))

print(math.asin(0.5))

print(math.atan(5))

print(math.cos(3))

print(math.degrees(0.1))

print(math.radians(5.729577795))

print(math.pi)

print(math.e)
