import os
os.chdir('/')
import subprocess
#print(subprocess.call('ls','-1'))
